package com.example.tdd;

public class StringCalculator {

	public int sum(String numbers) {
        if (numbers.length() < 2) {
            if (numbers.isEmpty()) {
                return 0;
            } else {
                return convertToInteger(numbers);
            }
        } else {
            String delimiter = ",";
            if (numbers.matches("//(.*)\n(.*)")) {
                delimiter = Character.toString(numbers.charAt(2));
                numbers = numbers.substring(4);
            }

            String[] numList = splitNumbers(numbers, delimiter + "|\n");
            return addNumbers(numList);
        }
    }

    private String[] splitNumbers(String numbers, String divider) {
        return numbers.split(divider);
    }

    private int convertToInteger(String num) {
        return Integer.parseInt(num);
    }

    private int addNumbers(String[] numbers) {
        int result = 0;
        StringBuilder negativeValue = new StringBuilder();

        for (String num : numbers) {
            if (convertToInteger(num) < 0) {
                if (negativeValue.toString().equals(""))
                    negativeValue = new StringBuilder(num);
                else
                    negativeValue.append(",").append(num);
            }
            if (convertToInteger(num) > 0)
                result += convertToInteger(num);
        }

        if (!negativeValue.toString().equals("")) {
            throw new IllegalArgumentException("Negative values not allowed: " + negativeValue);
        }

        return result;
    }
	
	
}

