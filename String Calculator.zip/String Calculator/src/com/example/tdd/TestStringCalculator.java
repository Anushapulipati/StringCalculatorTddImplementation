package com.example.tdd;


import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestStringCalculator {
	
	private StringCalculator stringCalculator;
	
	@BeforeEach
    public void init() {
        stringCalculator = new StringCalculator();
    }

	@Test
    public void testEmptyString() {
        assertEquals(0, stringCalculator.sum(""));
    }
	
	@Test
	public void testOneNumber() {
		assertEquals(5, stringCalculator.sum("5"));
	}

	@Test
	public void testTwoNumbers() {
		assertEquals(9, stringCalculator.sum("7,2"));
	}
	
	@Test
	public void testMultipleNumbers() {
		assertEquals(23, stringCalculator.sum("1,2,5,7,8"));
	}

	@Test
	public void testNewLineBetweenNumbers() {
		assertEquals(20, stringCalculator.sum("4\n6,2\n8"));
	}

	@Test
	public void testOtherDelimiters() {
		assertEquals(10, stringCalculator.sum("//;\n8;2"));
	}
	
	@Test
	public void testNegativeNumber() {
		try {
			stringCalculator.sum("-10,2");
		} catch (IllegalArgumentException e) {
			assertEquals(e.getMessage(), "Negative values not allowed: -10");
		}
		try {
			stringCalculator.sum("1,-3,3,-50");
		} catch (IllegalArgumentException e) {
			assertEquals(e.getMessage(), "Negative values not allowed: -3,-50");
		}
	}
}
